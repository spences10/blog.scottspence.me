---
title: FreeCodeCamp
date: "2016-10-24"
layout: post
path: "/freeCodeCamp/"
category: "Learning"
description: "Ok, I have recently discovered and started doing [FreeCodeCamp](https://www.freecodecamp.com/) which so far I'm really enjoying."
---

Since being out of work I have had some time to start exploring different programming languages and technologies but I haven't found any courses that I have started and thought "you know what I'm going to stick this out" that's before I discovered FCC, FCC is very much a real world situation course where you go over some basics first then apply them, once you have learnt enough you then have to complete projects using the skills you have just learned.

So far I have made a tribute page [DJ Hype](http://codepen.io/spences10/full/NbqZob/) and created a personal [Portfolio](http://codepen.io/spences10/full/NbGXoy/) page on [CODEPEN.io](http://codepen.io/spences10/) there's some great examples on [CODEPEN.io](http://codepen.io/) to help you get started and so far I have really enjoyed them.

So now onto JavaScript!

 
