---
title: "Hello World!"
date: "2016-10-24"
layout: post
path: "/hello-world/"
category: "TESTS"
description: "First post!"
---

My first post using Gatsby, awesome static site generator [Gatsby][gatsby] from [Kyle Mathews][kyle] 

So not a lot to see, I'll just be configuring this and adding all my old blog posts.

<!-- Links -->
[gatsby]: https://github.com/gatsbyjs/gatsby
[kyle]: https://github.com/KyleAMathews
